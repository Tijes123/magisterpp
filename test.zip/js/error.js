const init = function() {
    //// window.location.replace(window.location.href.substring(0, window.location.href.lastIndexOf("/")));
    //// window.location.reload()

    /// Hide text
    // const podium = document.getElementsByClassName("podium");
    // const textDiv = podium[0].children[1];
    // textDiv.className = "goaway";

    window.open(window.location.href.substring(0, window.location.href.lastIndexOf("/")), "_self")

}

init();